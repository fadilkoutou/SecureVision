SECUREVISION V2 — PROTOTYPE INTERACTIF

OUVRIR
1. Décompressez le fichier ZIP.
2. Ouvrez index.html dans Safari, Chrome, Edge ou Firefox.
3. Sur iPhone, si l’ouverture depuis Fichiers ne fonctionne pas correctement, il faudra héberger le dossier sur un service HTTPS pour l’utiliser facilement dans Safari.

CE QUI FONCTIONNE DANS CE PROTOTYPE
- Tableau de bord responsive.
- Inventaire des caméras : recherche, ajout, détails et création d’un incident associé.
- Réseau & sécurité : schéma pédagogique et bonnes pratiques.
- Incidents : création, suivi et clôture.
- Clients & équipe : données d’exemple et aperçu des rôles.
- Centre d’apprentissage : leçons et progression.
- Rapports : export CSV.
- Choix de rôle pour prévisualiser les interfaces.
- Sauvegarde des données de démonstration dans le stockage local du navigateur.

LIMITES IMPORTANTES
Il s’agit d’une vraie interface frontend interactive, mais pas encore d’une plateforme serveur prête à l’exploitation. Les caméras, adresses IP, états et alertes sont des données de démonstration. Aucun flux vidéo réel n’est connecté, aucun scan réseau n’est exécuté, et le sélecteur de rôle ne constitue pas une autorisation sécurisée. Les données sont conservées uniquement dans ce navigateur sur cet appareil.

POUR UNE VERSION DE PRODUCTION
Il faudra un backend et une base de données, des comptes sécurisés et des permissions par rôle côté serveur, HTTPS, sauvegardes, journalisation, tests, et une intégration autorisée aux caméras/NVR compatibles (par exemple RTSP/ONVIF via un serveur sécurisé). Il faudra également définir les règles de confidentialité, d’accès et de conservation des vidéos conformément aux lois applicables au Cameroun.
